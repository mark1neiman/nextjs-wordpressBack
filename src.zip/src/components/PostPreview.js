import Link from 'next/link';

export default function PostPreview({ post }) {
    return (
        <div>
            <Link href={`/${post.category.node.slug}/${post.slug}`}>
                <a>
                    <h2>{post.title}</h2>
                    <p>{post.excerpt}</p>
                </a>
            </Link>
        </div>
    );
}
