import { useQuery } from "@apollo/client";
import { POST_BY_SLUG_QUERY1 } from "../../../lib/queries";
import { apolloClient } from "../../../lib/apollo-client";
import { useRouter } from 'next/router';

const PostPage = () => {
  const router = useRouter();

  if (router.isFallback) {
    return <div>Loading...</div>;
  }

  const { slug } = router.query;
  const { loading, error, data } = useQuery(POST_BY_SLUG_QUERY1, {
    variables: { slug },
    client: apolloClient,
  });

  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error: {error.message}</p>;

  const post = data.post;

  return (
    <div>
      <h1>{post.title}</h1>
      <p>{post.content}</p>
    </div>
  );
};

export default PostPage;
